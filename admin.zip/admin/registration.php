<?php
include 'connection.php';

if (isset($_POST["submit"])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $role = $_POST['role'];

    $hashedpassword = password_hash($password, PASSWORD_DEFAULT);
    $hashedrepassword = password_hash($repassword, PASSWORD_DEFAULT);

    $sql = "INSERT INTO registration (name, username, password, repassword, role) 
            VALUES ('$name', '$username', '$hashedpassword', '$hashedrepassword', '$role')";

   
    $result = $conn->query($sql);


    if ($result === TRUE) {
        echo '';
    } else {
        echo 'Error: ' . $sql . '<br>' . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Form Validation</title>
    <style>
        body {
            background-color: skyblue;
            background-repeat: no-repeat;
            background-size: 1500px 620px;
            text-align: center;
            font-size: 22px;
            color: white;
        }

        h1 {
            color: white;
            font-size: 40px;
            font-family: sans-serif;
        }

        input,
        select {
            width: 300px;
            height: 30px;
            border-radius: 7px;
            margin-top: 10px;
        }

        input[type="submit"] {
            font-size: 20px;
            height: 40px;
            background-color: #00FF7F;
            margin-top: 20px;
        }

        input[type="submit"]:hover {
            color: white;
       
        }

        fieldset {
            margin-left: 580px;
            border: 2px solid black;
            width: 350px;
            border-radius: 10px;
        }

        legend {
            font-size: 24px;
            font-weight: bold;
            color: white;
            padding: 10px;
            background-color: #333;
            border-radius: 5px;
        }

        .icon {
            margin-left: 10px;
            font-size: 10px;
            border: 2px solid black;
            border-radius: 10px;
            padding: 5px;
        }

        .input-group {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .password-toggle {
            cursor: pointer;
            border-radius: 7px;
            margin-right: -40px;
         
          
            background-color: #ddd;
        }
        .submit{
            margin-top:150px;
        }
    </style>
</head>

<body>
    <div class="main">
        <div class="form1">
            <form method="post" action="registration.php">
                <fieldset style="border: 2px solid black;margin-left: 580px;width: 350px;border-radius: 10px;width:380px;">
                    <legend>Registration</legend>

                    <div class="input-group">
                        <span class="icon">👤</span>
                        <input type="text" placeholder="Name" class="names" name="name" required>
                    </div>

                    <div class="input-group">
                        <span class="icon">👤</span>
                        <input type="text" placeholder="USERNAME" class="usernames" name="username" required>
                    </div>

                    <?php
                    if (isset($_POST["submit"])) {
                        $username = $_POST['username'];
                        if (strpos($username, '@') === false || !preg_match('/[A-Z]/', $username)) {
                            echo "<h5>Username must contain '@' symbol and at least one uppercase letter</h5>";
                        }
                    }
                    ?>

                    <div class="input-group">
                        <span class="icon">🔒</span>
                        <input type="password" placeholder="Password" class="passwords" name="password" id="passwordinput" required>
                        <span class="password-toggle" onclick="togglePasswordVisibility('passwordinput')" style="margin-left:-20px;height:10px;margin-top:5px;">👁️</span>
                    </div>

                    <div class="input-group">
                        <span class="icon">🔒</span>
                        <input type="password" placeholder="RePassword" class="repasswords" name="repassword" id="repasswordinput" required>
                        <span class="password-toggle" onclick="togglePasswordVisibility('repasswordinput')"style="margin-left:-20px;height:10px;margin-top:5px;">👁️</span>
                    </div>

                    <?php
                    if (isset($_POST["submit"])) {
                        $password = $_POST['password'];
                        $repassword = $_POST['repassword'];
                        if ($password != $repassword) {
                            echo "<h5>Password and repassword are not matched</h5>";
                        }
                    }
                    ?>

                    <div class="input-group">
                        <span class="icon">🧍‍♀️</span>
                        <select id="role" option="values" class="roles" name="role" required>
                
                            <option value="superuser">superUser</option>
                            <option value="employee">Employee</option>
                            <option value="user">user</option>
                        </select>
                    </div>

                    <input type="submit" value="Submit" name="submit" class="submit" ><br><br>
                </fieldset>
            </form>
        </div>
    </div>

    <script>
        function togglePasswordVisibility(inputId) {
            var passwordInput = document.getElementById(inputId);
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        }
    </script>
</body>

</html>
