<?php
require("connection.php");

include "login.php";

if (isset($_POST['signin'])) {
    $name = $_POST['username'];
    $password = $_POST['password'];

    // Using prepared statements to prevent SQL injection
    $query = "SELECT * FROM `admin_login` WHERE `name` = '$name' AND `password` = '$password'";
    $stmt = mysqli_prepare($conn, $query);
  
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 1) {
        session_start();

        // Regenerate session ID to prevent session fixation
        session_regenerate_id(true);

        $_SESSION['username'] = $name;
        header('Location: Admin panel.php');
        exit();
    } 
    // Close the prepared statement
    mysqli_stmt_close($stmt);

}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Superuser Dashboard</title>
    
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&family=Roboto:wght@500;700;900&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
<body>
    <!-- Login form section -->
    <div class="login-form">
        <!-- Form header -->
        <center><h2>ADMIN LOGIN FORM</h2></center>

        <!-- Login form -->
        <form method="POST" action=""  >
            <fieldset style="border: 2px solid black;margin-left: 580px;width: 350px;border-radius: 10px;width:380px; padding:25px;" >
                <!-- Username input field -->
                <div class="input-field" style="margin-left:50px;margin-bottom:15px;">
                    <i class="fas fa-user"></i>
                    <input type="text" placeholder="ADMIN NAME" name="username">
                </div>

                <!-- Password input field with a password toggle button -->
                <div class="input-field" style="margin-left:50px;margin-bottom:15px;">
                    <i class="fas fa-lock"></i>
                    <input type="password" placeholder="ADMIN PASSWORD" name="password" id="passwordinput">
                    <span class="password-toggle" onclick="togglePasswordVisibility('passwordinput')" style="margin-left:-30px;height:10px;margin-top:5px;">👁️</span>
                </div>        
                <?php
               if (isset($_POST['signin'])) {

                $password = $_POST['password'];
                if($password==true){
                    echo"incorrect password";
                } 
            }
                ?>
                <div class="extra">
                    <a href="#">Forget Password?</a>
                </div>

                <!-- Submit button -->
                <center><button type="submit" name="signin">Signin</button><center>

                <!-- Forget password link -->

        </fieldset>
        </form>
    </div>

    <!-- Additional scripts and libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <!-- ... Other scripts ... -->

    <!-- Password toggle script -->
    <script>
        function togglePasswordVisibility(inputId) {
            var passwordInput = document.getElementById(inputId);
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        }
    </script>

</body>

</html>
